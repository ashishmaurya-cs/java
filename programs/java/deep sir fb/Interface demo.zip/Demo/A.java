
public class A extends CV{
	@Override
	public void head() {
	System.out.println("2 head");
	}
	
	@Override
	public void wheel() {
	System.out.println("4 wheel");
	
	}
	@Override
	public void gear() {
	System.out.println("automatic");
	
	}
}
