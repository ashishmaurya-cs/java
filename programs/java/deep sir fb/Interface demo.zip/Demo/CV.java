
public abstract class CV implements V {

	@Override
	public void gear() {
		System.out.println("4 gear");
		
	}

	@Override
	public void head() {
	System.out.println("1 head");
		
	}
	@Override
	public void wheel() {
		System.out.println("2 wheel");
		
	}

}
