import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;


public class Mouse extends MouseAdapter{
	@Override
	public void mouseEntered(MouseEvent e) {
	
	
	}
	@Override
	public void mouseExited(MouseEvent e) {
	
	
	}
}
