
public interface V {
void gear();
void wheel();
void head();
}
