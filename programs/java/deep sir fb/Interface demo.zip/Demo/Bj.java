
public class Bj extends CV {
	
}